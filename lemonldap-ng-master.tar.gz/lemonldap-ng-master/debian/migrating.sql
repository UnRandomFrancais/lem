ALTER TABLE lmConfig ADD COLUMN timeout int;
