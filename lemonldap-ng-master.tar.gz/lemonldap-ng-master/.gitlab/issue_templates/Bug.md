### Concerned version

Version: %X.X.X

Platform: (Nginx/Apache/Node.js)

### Summary

Summarize the bug encountered concisely

### Logs

```
Set here the logs using debug mode if possible. Attach it as file if it's too big
```

### Backends used

For any bug on configuration/sessions storage, give us details on backends

### Possible fixes

