### Summary

Summarize the new feature encountered concisely

### Design proposition

Describe here the process imaginated (interface design suggest, proposed process,…)
