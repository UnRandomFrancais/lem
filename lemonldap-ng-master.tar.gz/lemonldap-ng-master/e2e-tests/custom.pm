package My;

sub hello {
    return 'Hello';
}

sub get_additional_arg {
    return $_[0];
}

1;
